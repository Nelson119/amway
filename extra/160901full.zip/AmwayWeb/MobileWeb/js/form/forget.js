'use strict';
/*eslint-disable new-cap, no-unused-vars,
	no-use-before-define, no-trailing-spaces, space-infix-ops, comma-spacing,
	no-mixed-spaces-and-tabs, no-multi-spaces, camelcase, no-loop-func,no-empty,
	key-spacing ,curly, no-shadow, no-return-assign, no-redeclare, no-unused-vars,
	eqeqeq, no-extend-native, quotes , no-inner-declarations*/
/*global  $, app */

app.forget = function (global) {
	// console.log('index initialized');

	var authorize = global.authorize,
	    message = global.message,
	    method = global.method,
	    debug = global.debug,
	    dayOfMonth = global.dayOfMonth;

	$("#login_submit").click(function () {
	    if ($('#edtIDNNO').val() == "") {
	        alert('請輸入身分證/護照/外僑統一證號號碼');
	        $('#edtIDNNO').focus();
	        return false;
	    }
	    if ($('#byear').val() == "") {
	        alert('請輸入生日民國年');
	        $('#byear').focus();
	        return false;
	    }
	    if ($('#bmonth').val() == "") {
	        alert('請輸入生日月份');
	        $('#bmonth').focus();
	        return false;
	    }
	    if ($('#bday').val() == "") {
	        alert('請輸入生日');
	        $('#bday').focus();
	        return false;
	    }
	    $('#a1form').submit();
	    return false;
	});

	(function () {
		var src = $('header h1 a img').attr('src');
		$.get(src, function (response) {
			$('header h1 a').html($('svg', response));
		});

		//下拉選單
		if ($('.forget-form').length) {

			$('select[name=birthday]').eq(0).on('change', function (e) {
				var pick = $('select[name=birthday]').eq(1).find('option').clone();
				pick.eq(0).siblings().attr('selected', null);
				pick.eq(0).attr('selected', 'selected');
				$('select[name=birthday]').eq(1).find('option').remove();
				$('select[name=birthday]').eq(1).append(pick);

				pick = $('select[name=birthday]').eq(2).find('option').clone();
				pick.eq(0).siblings().attr('selected', null);
				pick.eq(0).attr('selected', 'selected');
				$('select[name=birthday]').eq(2).find('option').remove();
				$('select[name=birthday]').eq(2).append(pick);
			});

			$('select[name=birthday]').eq(1).on('change', function (e) {
				var pick = $('select[name=birthday]').eq(2).find('option').clone();
				pick.eq(0).siblings().attr('selected', null);
				pick.eq(0).attr('selected', 'selected');
				$('select[name=birthday]').eq(2).find('option').remove();
				$('select[name=birthday]').eq(2).append(pick);

				var index = $('select[name=birthday]').eq(1).find('option:selected').val() - 1;
				var days = dayOfMonth[index];

				$('select[name=birthday]').eq(2).find('option').removeClass('hide');
				$('select[name=birthday]').eq(2).find('option:gt(' + days + ')').addClass('hide');
			});
		}
	})();
};
//# sourceMappingURL=forget.js.map
