﻿'use strict';
/*eslint-disable new-cap, no-unused-vars,
	no-use-before-define, no-trailing-spaces, space-infix-ops, comma-spacing,
	no-mixed-spaces-and-tabs, no-multi-spaces, camelcase, no-loop-func,no-empty,
	key-spacing ,curly, no-shadow, no-return-assign, no-redeclare, no-unused-vars,
	eqeqeq, no-extend-native, quotes , no-inner-declarations*/
/*global  $, app */

app.login = function (global) {
    // console.log('index initialized');

    var authorize = global.authorize,
	    message = global.message,
	    method = global.method,
	    debug = global.debug,
	    dayOfMonth = global.dayOfMonth;

    window.freeze = true;

    //global.loading.on();
    //global.loading.off();

    (function () {
        var src = $('header h1 a img').attr('src');
        $.get(src, function (response) {
            $('header h1 a').html($('svg', response));
        });
    })();

    $("#login_submit").click(function () {
        if (!/^\d{7}$/.test($('#edtID').val())) {
            alert('請輸入正確編號!');
            return false;
        }
        if (/^\d{5}$/.test($('#edtPW').val()) || /^(?=.*\d)(?=.*[a-zA-Z]).{6,8}$/.test($('#edtPW').val())) {
        }
        else {
            alert('請輸入正確密碼!');
            return false;
        }
        if ($('#edtPW').val().length < 5 || $('#edtPW').val().length > 8) {
            alert('請輸入正確密碼!');
            return false;
        }
        $('#a1form').submit();
        return false;
    });

    if (gsNewLoginToken != '') {
        if (gbIsResetPW) {
            global.loading.on();
            setTimeout(function () {
                location.href = 'reset-password.aspx';
            }, 100);
        }
        else if (gbIsRenew) {
            //$('.ibPopConfirm').show();


            // -- 20160725修改
            app.global.message.confirm({
                content: '您的直銷商/生活會員權利已到期，提醒您可以於線上完成續約以保障相關權益。欲辦理續約<br>請點選「續約」。',
                confirm: '續約',
                cancel: '取消'
            }, function () {
                setTimeout(function () { location.href = 'renew.aspx'; }, 100);
            });

            // -- /.20160725修改
        }
        else {
            global.loading.on();
            setTimeout(function () { location.href = 'index.aspx'; }, 100);
        }
        return;
    }
};
//# sourceMappingURL=login.js.map
