'use strict';
/*eslint-disable new-cap, no-unused-vars,
	no-use-before-define, no-trailing-spaces, space-infix-ops, comma-spacing,
	no-mixed-spaces-and-tabs, no-multi-spaces, camelcase, no-loop-func,no-empty,
	key-spacing ,curly, no-shadow, no-return-assign, no-redeclare, no-unused-vars,
	eqeqeq, no-extend-native, quotes , no-inner-declarations,  no-alert*/
/*global  $ */

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol ? "symbol" : typeof obj; };

var app = {};

// 全域使用的物件
app.global = {};

// 網址為 gulp 或者 github 時 設定成debug 模式
var debug = app.global.debug = /localhost[:]9000|nelson119.github.io/.test(location.href);

// 每個月要顯示的天數
var dayOfMonth = app.global.dayOfMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

// ajax 表單使用post 或 debug時用get
var method = app.global.method = debug ? 'get' : 'post';

// 下方顯示提示
var message = {};

message.alert = function (msg, keep) {
	alert(msg);

	// if(keep){
	// 	$('#message')
	// 		.html(msg)
	// 		.removeClass('hide')
	// 		.addClass('in');
	// }else {
	// 	$('#message')
	// 		.html(msg)
	// 		.removeClass('hide')
	// 		.addClass('in')
	// 		.fadeOut(8000, function(){
	// 			$(this)
	// 				.addClass('hide')
	// 				.removeClass('fade')
	// 				.removeAttr('style');
	// 		});
	// }
};

// -- 20160725修改
message.confirm = function (msg, callback) {
    $('#confirm .text').html(msg.content);
    $('#confirm')
        .css('z-index', '100')
        .removeClass('hide')
        .addClass('in');
    $('#btnMessageConfirm').html(msg.confirm).unbind('click').on('click', function () {

        callback();
        $('#confirm').removeClass('in');
        setTimeout(function () {
            $('#confirm').addClass('hide');
        }, 300);
    });
    $('#btnMessageCancel').html(msg.cancel).unbind('click').on('click', function () {
        $('#confirm').removeClass('in');
        setTimeout(function () {
            $('#confirm').addClass('hide');
        }, 300);
    });

};
// -- /.20160725修改



message.confirmOff = function () {
    $('#confirm').removeClass('in');
    setTimeout(function () {
        $('#confirm').addClass('hide');
    }, 300);
};

app.global.message = message;

// end 下方顯示提示

$(function () {

	$('form').on('submit', function (e) {
		var form = this;
		setTimeout(function () {
			form.submit();
		}, 200);
		e.stopPropagation();

		e.preventDefault();

		return false;
	});

	// 加入頁面各自的程式	
	$.each(app, function (name, init) {
		if (name == 'global') {
			return;
		}
		// console.log(name);
		// console.log('debug', debug);
		if ($('.section.' + name).length) {
			init(app.global);
		}
	});

	//調整頁面尺寸事件處理
	$(window).on('resize', function () {
		if (!window.freeze) {
			$('html').addClass('ready');
		}
	});

	//觸發第一次調整頁面尺寸
	$(window).trigger('resize');
});

//表單驗證
function valid(form) {
	var result = true;
	// console.log($('input, select, textarea', form))
	try {
		$('input, select, textarea', form).each(function (index, input) {
			var field = {};
			input = $(input);
			field.name = input.attr('data-name') || input.attr('name');
			field.required = input.hasAttr('required');
			field.patern = input.attr('pattern');
			field.value = input.val();
			if (field.required && !field.value) {
				message.alert('請填寫' + field.name);
				result = false;
			}
			if (!new RegExp(field.pattern).test(field.value)) {
				message.alert(field.name + ' 格式錯誤');
				result = false;
			}
		});
	} catch (e) {
		// console.log(e);
	}

	return result;
}

//判斷是否具有屬性
$.fn.hasAttr = function (attributeName) {
	var attr = $(this).attr(attributeName);
	if ((typeof attr === 'undefined' ? 'undefined' : _typeof(attr)) !== (typeof undefined === 'undefined' ? 'undefined' : _typeof(undefined)) && attr !== false) {
		return true;
	} else {
		return false;
	}
};

//顯示 loading
var loading = {};
loading.on = function () {
	$('body').addClass('loading');
};

loading.off = function () {
	$('body').addClass('loading');
};

//顯示 overlay
var loading = {};
loading.on = function () {
    $('body').addClass('loading');
};

loading.off = function () {
    $('body').addClass('loading');
};

app.global.loading = loading;
//# sourceMappingURL=app.js.map
